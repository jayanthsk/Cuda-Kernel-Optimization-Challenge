This folder contains 5 Sub-folders

-------- CODE ----------
Here you will find 2 python files for generating large datasets used to evaluate our parallel compute patterns.
In here there are 3 folders for the 3 pattens: Stencil, Histogram, Reduction. 
Each folder has their corresponding main.cuh file and a .cuh file for each kernel

-------- Datasets----------
Here you will find 2 python files for generating large datasets used to evaluate our parallel compute patterns.
Additionally, there are 3 folders for the three patterns. In each folder, there are two files that contains 
data for each pattern. The smaller one was used during testing and optimization, and the larger is the dataset we used
for our final run.

-------- Night Compute and exe - best case----------
This folder contains the NSIGHT Compute profiling files for the best kernels ran on the final dataset as well as the EXE files
to create them.

-------- Night Compute and exe - testing----------
This folder contains the NSIGHT Compute profiling files for the various kernels we looked at for each pattern along with their
.exe files


-------- Nsight Systems----------
This folder has the results for NSIGHT SYSTEMS for each of the best kernels per pattern


