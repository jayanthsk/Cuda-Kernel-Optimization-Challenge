import numpy as np

# FUNCTION to generate a binary file consisting of user-specified number of
# random uniformly-distributed numerical values of user-specified precision: int8, float16, or float32.
# see bottom for USAGE examples for the Kernel Challenge Dataset generation
def generate_binary_file(filename, num_values, dtype):
    # Define the data type based on user input
    if dtype not in ['int8', 'float16', 'float32','ones']:
        raise ValueError("Unsupported dtype. Use 'int8', 'float16', or 'float32'.")

    # Generate random uniformly-distributed values
    if dtype == 'ones':
        data = np.ones(num_values, dtype='float32')
    elif 'int' in dtype:
        data = np.random.randint(low=np.iinfo(np.dtype(dtype)).min,
                                 high=np.iinfo(np.dtype(dtype)).max,
                                 size=num_values,
                                 dtype=dtype)
    else:
        data = np.random.uniform(low=0.0, high=1.0, size=num_values).astype(dtype)

    # Write the data to a binary file
    with open(filename, 'wb') as file:
        file.write(data.tobytes())

#==============================================================================================
# USAGE: uncomment the section below to generate the corresponding Kernel Challenge Dataset

# 3D_STENCIL GRID : Example usage for Kernel Challenge Dataset - 3D_STENCIL GRID
out_filename = '3dgrid_all-ones_768x768x768_float32.bin' # output file path & name
num_values = 768**3  # User-specified number of values
dtype = 'ones'  # User-specified precision: 'int8', 'float16', or 'float32'
generate_binary_file(out_filename, num_values, dtype)

# REDUCE : Example usage for Kernel Challenge Dataset - REDUCE
#out_filename = 'reduce_all-ones_n204.8M_float32.bin' # output file path & name
#num_values = int(204_800_000) # User-specified number of values
#print('num_values', num_values)
#dtype = 'ones'  # User-specified precision: 'int8', 'float16', or 'float32'
#generate_binary_file(out_filename, num_values, dtype)

