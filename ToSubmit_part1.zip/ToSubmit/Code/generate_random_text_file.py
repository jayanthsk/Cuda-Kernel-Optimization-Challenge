import random
import string

# ======
# Function to generate UTF-8 format text file containing only lowercase + UPPERcase alphabetic
# characters of specified size
def generate_random_text_file(filename, num_chars):
    # Define the characters to choose from (lowercase letters only)
    #chars = string.ascii_letters + ' '
    chars = string.ascii_lowercase

    # Generate the random content
    content = ''.join(random.choice(chars) for _ in range(num_chars))

    # Write the content to a UTF-8 encoded text file
    with open(filename, 'w', encoding='utf-8') as file:
        file.write(content)

# ==== Example function usage
# output filename
filename = 'random_lowercase_utf8_n1B.txt'
# number of alphabetic characters to generate
num_chars = 1_000_000_000
# execute function
generate_random_text_file(filename, num_chars)
